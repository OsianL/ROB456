#!/usr/bin/env python3

import numpy as np

import sys
import rospy
import signal
import time

from controller import RobotController
import exploring as explore
import path_planning as pathplan

class StudentController(RobotController):
	'''
	This class allows you to set waypoints that the robot will follow.  These robots should be in the map
	coordinate frame, and will be automatially sent to the code that actually moves the robot, contained in
	StudentDriver.
	'''
	def __init__(self):
		super().__init__()

		#Setup some variables for our timeout system
		self.goal_start_time = time.time()
		self.making_progress = True
		self.goal_timeout = 90
		
		#Setup some variables for checking where we've been:
		self.prev_goalpoints = []
		self.goalpoint_tolerance = 50 #pixels

		#an initial variable for handing the valid robot location problem:
		self.initial_map_update = True

	#makes it easier to record previous goalpoints without adding duplicates
	def add_prev_goal(self,goal):
		if not goal in self.prev_goalpoints:
			self.prev_goalpoints.append(goal)

	#TODO: Refactor this to use real measurements rather than pixels:
	#Checks all our goalpoints against the list of points we have already visited to keep us from bouncing back and forth:
	def check_goalpoints(self, detected_goalpoints):
		
		valid_goalpoints = []

		#Look at each detected goalpoint:
		for detected in detected_goalpoints:
		
			#Assume point is valid
			valid = True

			#compare it with each previous goalpoint
			for prev in self.prev_goalpoints:
				
				#Calculate the distance from each prev goalpoint
				dist = np.hypot(detected[0]-prev[0],detected[1]-prev[1])

				#mark it as invalid if it is inside the tolerance radius of any of the previous goalpoints:
				if (dist < self.goalpoint_tolerance):
					valid = False
			
			#if it makes it past all the previous goalpoints and is still valid, append it to the list of valid points: 
			if valid == True:
				valid_goalpoints.append(detected)

		
		#print the valid and previous goalpoints for debugging:
		rospy.loginfo(f'Previous Goalpoints: {self.prev_goalpoints}')
		rospy.loginfo(f'Valid Goalpoints: {valid_goalpoints}')

		#return the list of valid goalpoints:
		return valid_goalpoints

	#Since Our A* Implementation complains if the robot is not in a valid whitespace, we move forward ever so slightly on the first map update
	#Kind of hacky, but this ensures that we are in a valid location for path planning.
	def initial_move(self, robot_location):
		#only move a very small amount from the robot's starting location:
		initial_move = 0.5 #meters
		initial_waypoint = (robot_location[0] + initial_move,robot_location[1] + initial_move)

		#set the initial waypoint
		self.set_waypoints((initial_waypoint,initial_waypoint))


	def distance_update(self, distance):
		'''
		This function is called every time the robot moves towards a goal.  If you want to make sure that
		the robot is making progress towards it's goal, then you might want to check that the distance to
		the goal is generally going down.  If you want to change where the robot is heading to, you can
		make a call to set_waypoints here.  This call will override the current set of waypoints, and the
		robot will start to drive towards the first waypoint in the new list.

		Parameters:
			distance:	The distance to the current goal.
		'''
		rospy.loginfo(f'Distance: {distance}')

		'''

		-use this function to check that robot is making progress to goal, implement way to send new waypoints if
		reasonable amount of progress isnt made in some timeframe (idk how to access time here tho)


		note:besides above use case i generally dont think we want to set waypoints here unless we arent getting map updates,
		there should be some way to guarantee we can find new goals even if we dont get map update?
		-when this function runs force map_update to run (if statement to make it not actually run if we are making progress?)

		'''
		
		#units are in seconds
		#there might be an error for start_travelling_time on first program loop?
		travelling_time = time.time() - self.goal_start_time

		#gives robot ~60 seconds to reach goal location
		if travelling_time > self.goal_timeout:
			rospy.loginfo('FAILED TO REACH GOALPOINT IN ALLOCATED TIME, RECALCULATING')
			self.making_progress = False
		else:
			self.making_progress = True


	def map_update(self, point, map, map_data):
		'''
		This function is called every time a new map update is available from the SLAM system.  If you want
		to change where the robot is driving, you can do it in this function.  If you generate a path for
		the robot to follow, you can pass it to the driver code using set_waypoints().  Again, this will
		override any current set of waypoints that you might have previously sent.

		Parameters:
			point:		A PointStamped containing the position of the robot, in the map coordinate frame.
			map:		An OccupancyGrid containing the current version of the map.
			map_data:	A MapMetaData containing the current map meta data.
		'''

		rospy.loginfo('Got a map update.')

		# It's possible that the position passed to this function is None.  This try-except block will deal
		# with that.  Trying to unpack the position will fail if it's None, and this will raise an exception.
		# We could also explicitly check to see if the point is None.
		try:
			# The (x, y) position of the robot can be retrieved like this.
			robot_position = (point.point.x, point.point.y)

			rospy.loginfo(f'Robot is at {robot_position} {point.header.frame_id}')
		except:
			rospy.loginfo('No odometry information')
			
			#return 1 to prevent the rest of the function from running
			return 1

		#Now That we're sure the map update is valid, check if the robot has waypoints already or not
		# distance update here and waypoint check in student_driver.py will remove the waypoints if we aren't making any progress
		
		#Check if _waypoints is None or empty:
		has_waypoints = True
		#Need to handle _waypoints == None
		try:
			if len(self._waypoints) == 0:
				has_waypoints = False
		except:
			has_waypoints = False

		#Map updates are configured to always run in the launch file (even when the robot is still)
		#Check if we need to generate new waypoints:
		if has_waypoints == False or self.making_progress == False:

			#step -1: check if this is our first map update:
			if self.initial_map_update:
				rospy.loginfo('INITIAL MAP UPDATE HAPPENING')
				#make sure this only happens once:
				self.initial_map_update = False
				#make the robot move into valid whitespace slightly
				self.initial_move(robot_position)
				#return 0 to prevent any other updates from happening this callback:
				return 0

			#Step 0:
			#Convert the map into a more useful form:
			im = np.array(map.data).reshape(map.info.height,map.info.width)
			im_thresh = pathplan.convert_image(im, 0.7, 0.9)
			map_dims = (map.info.width,map.info.height)
			
			#log map info:
			rospy.loginfo(f'Map Width: {map.info.width}, Height: {map.info.height}, Res: {map.info.resolution}')

			#Convert robot location to map pixel location
			robot_map_loc = explore.convert_x_y_to_pix(map_dims,robot_position,map.info.resolution)
			#adding this handles the starting edgecase where our list of previous goals is empty
			self.add_prev_goal(robot_map_loc)
			rospy.loginfo(f'Robot map location: ({robot_map_loc[0]},{robot_map_loc[1]})')

			#Step 1: Find all possible goals
			all_goals = explore.find_all_possible_goals(im_thresh)
			#rospy.loginfo(f'all_goals: {all_goals}')
			

			#Step 1.5: Compare the possible goals with the previous goals:
			valid_goals = self.check_goalpoints(all_goals)
			
			#IF THERE ARE NO MORE VALID GOALPOINTS, THEN WE ARE DONE:
			if len(valid_goals) < 2:
				rospy.loginfo('MAPPING COMPLETE, NO MORE GOALPOINTS TO VISIT')
				return 0

			#TODO: hold all possible goals in a queue
			#Compare possible goals with goals we already attempted to reach (spatially: w/i radius)

			#Step 2: Find best goal of possible goals
			best_goal = explore.find_best_point(im_thresh,valid_goals,robot_map_loc)
			self.add_prev_goal(best_goal)
			rospy.loginfo(f'best goal point: {best_goal}')

			#Step 3: Get waypoints
			#Path plan
			path = pathplan.dijkstra(im_thresh,robot_map_loc,best_goal)
			#Get corner waypoints
			map_waypoints = explore.find_waypoints(im_thresh,path)
		
			#Step 4:
			#Convert outputs back into world units from map pixels
			waypoints = []
			for point in map_waypoints:
				waypoints.append(explore.convert_pix_to_x_y(map_dims,point,map.info.resolution))
			
			#Log the new waypoints real quick:
			rospy.loginfo(f'New Waypoints: {waypoints}')

			#Set waypoints
			self.set_waypoints(waypoints)

			#reset self.goal_start_time and self.making_progress
			self.goal_start_time = time.time()
			self.making_progress = True

		#defines what remaining counts as completing the mapping 
		#completion_percent = 0.01

		#possible goals defined in explore code (all goals we might want to send robot to)
		#if possible_goals_amount < completion_percent*explored_points_amount:
			#rospy.loginfo('Mapping complete, program ended.')
			#break #dont know how to end program

		return 0
	


if __name__ == '__main__':
	# Initialize the node.
	rospy.init_node('student_controller', argv=sys.argv)



	# Start the controller.
	controller = StudentController()

	# This will move the robot to a set of fixed waypoints.  You should not do this, since you don't know
	# if you can get to all of these points without building a map first.  This is just to demonstrate how
	# to call the function, and make the robot move as an example.
	#controller.set_waypoints(((-4, -4),(-4,-4)))

	# Once you call this function, control is given over to the controller, and the robot will start to
	# move.  This function will never return, so any code below it in the file will not be executed.
	controller.send_points()
