#!/usr/bin/env python3


import sys
import rospy

from new_driver import Driver

from math import atan2, sqrt, tanh
import numpy as np


class StudentDriver(Driver):
	'''
	This class implements the logic to move the robot to a specific place in the world.  All of the
	interesting functionality is hidden in the parent class.
	'''
	def __init__(self, threshold=0.1):
		super().__init__('odom')
		# Set the threshold to a reasonable number

		# waypoint nearness x threshold and y threshold
		self._threshold = [0.3,0.9]

		#Hold the 10 previous distance values in a circular buffer:
		self._prev_distances = np.zeros(150)
		self._epsilon_timeout = 0.05

	def close_enough_to_waypoint(self, distance, target, lidar):
		'''
		This function is called perioidically if there is a waypoint set.  This is where you should put any code that
		has a smarter stopping criteria then just checking the distance. See get_twist for the parameters; distance
		is the current distance to the target.
		'''
		# Default behavior.
		#if distance < self._threshold:
		#	return True
		
		#New behavior which seperates out the x and y directions since the robot is rectangular-ish
		#target coordinates assigned to variables for readability
		x_dist = target[0]
		y_dist = target[1]
		#Behavior to make robot able to reach waypoints near walls
		if (abs(x_dist) < 0.38+self._threshold[0]) and (abs(y_dist) < 0.38+self._threshold[1]):
			rospy.loginfo('Reached waypoint!')
			return True
		
		#Also check if we haven/haven't been getting anywhere:
		#Update the circular buffer:
		self._prev_distances = np.concatenate([np.array([distance]),self._prev_distances[0:-1]])
		rospy.loginfo(f'Distance:{distance}, last _prev_distances: {self._prev_distances[-1]}')
		#Check if the last and first entries in the buffer are significantly different
		if (self._prev_distances[-1] != 0) and (abs(distance - self._prev_distances[-1]) < self._epsilon_timeout):
			#If they're not then we haven't moved in a while and should skip this waypoint
			rospy.loginfo('No Movement, Skipping waypoint')
			self._prev_distances = np.zeros(150)
			return True
		

		#Otherwise we're still working our way towards the waypoint, keep on going:
		return False

	def get_twist(self, target, lidar):
		'''
		This function is called whenever there a current target is set and there is a lidar data
		available.  This is where you should put your code for moving the robot.  The target point
		is in the robot's coordinate frame.  The x-axis is positive-forwards, and the y-axis is
		positive to the left.

		The example sets constant velocities, which is clearly the wrong thing to do.  Replace this
		code with something that moves the robot more intelligently.

		Parameters:
			target:		The current target point, in the coordinate frame of the robot (base_link) as
						an (x, y) tuple.
			lidar:		A LaserScan containing the new lidar data.

		Returns:
			A Twist message, containing the commanded robot velocities.
		'''
		command = Driver.zero_twist()

		#Parameters:
		robot_width = 0.5 #meters
		epsilon_theta = 0.5 #Radians?
		avoidance_distance = 1 #meters
		min_forward_speed = 0.5
		min_theta_speed = 0.5

		# TODO:
		#  Step 1) Calculate the angle the robot has to turn to in order to point at the target
		
		#Assuming 'in the robot's coordinate frame' implies both positionally and rotationally  
		target_theta = atan2(target[1],target[0])
		target_distance = sqrt(target[0]**2 + target[1]**2)
		
		#  Step 2) Set your speed based on how far away you are from the target, as before
		theta_velo = 2*tanh(target_theta)
		forward_velo = tanh(target_distance)
		
		#  Step 3) Add code that veers left (or right) to avoid an obstacle in front of it
		
		# Pulling out some useful values from scan
		angle_min = lidar.angle_min
		angle_max = lidar.angle_max
		num_readings = len(lidar.ranges)

		# Doing this for you - get out theta values for each range/distance reading
		thetas = np.linspace(angle_min, angle_max, num_readings)
		
		#Check if there's an obstacle in front of the robot
		#Decompose scan into x and y coords using sin, cos
		y_readings = lidar.ranges * np.sin(thetas)
		x_readings = lidar.ranges * np.cos(thetas)

		#get the relevant perpendicular distances
		x_readings_in_way = x_readings[abs(y_readings) < (robot_width/2)]

		#Get the minimum distance to the closest object
		min_dist_to_obstacle = np.min(x_readings_in_way)
		
		#Check if there is an obstacle immediately in front of us:
		if (min_dist_to_obstacle < avoidance_distance):
			
			#Decide whether to curve left or right
			#This might be hacky, but we can do a sum of the laser scan halves
			#The larger sum indicates that there is more open space in that direction
			
			left_sum = 0
			right_sum =0
			for i in range(0,num_readings):
				if (angle_min < thetas[i] < 0):
					right_sum += lidar.ranges[i]
				elif (0 < thetas[i] < angle_max):
					left_sum += lidar.ranges[i]
			
			#Then just check which one is bigger:
			if (left_sum  > right_sum):
				#Turn left, turn faster if close to obstacle:
				theta_velo = tanh(avoidance_distance - min_dist_to_obstacle + min_theta_speed)
				forward_velo = tanh(min_dist_to_obstacle + min_forward_speed)
			else:
				#Turn Right
				theta_velo = -tanh(avoidance_distance - min_dist_to_obstacle + min_theta_speed)
				forward_velo = tanh(min_dist_to_obstacle + min_forward_speed)
		
		#If there's no obstacle, Wait until we are pointed at the target to move
		
		elif not (-epsilon_theta < target_theta < epsilon_theta):
			forward_velo = 0
		
		# This sets the move forward speed (as before)
		command.linear.x = forward_velo
		# This sets the angular turn speed (in radians per second)
		command.angular.z = theta_velo
		return command


if __name__ == '__main__':
	rospy.init_node('student_driver', argv=sys.argv)

	driver = StudentDriver()

	rospy.spin()
